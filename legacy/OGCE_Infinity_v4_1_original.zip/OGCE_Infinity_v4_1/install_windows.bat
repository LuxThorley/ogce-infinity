@echo off
py -3.10 -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -e .[render]
echo OGCE Infinity installed. Run: ogce4 create-project --name "My World" --out MyWorld
