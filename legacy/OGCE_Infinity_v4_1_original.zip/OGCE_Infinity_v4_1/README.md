# OGCE Infinity v4.1

OGCE v4.1 extends the v4.0 runnable foundation with engineering modules for PBR material data,
glTF 2.0 inspection, lighting/shadow configuration, GI probe interpolation, post-processing
configuration, deterministic procedural terrain, frame-time budgets, editor undo/redo and docking
layout schemas, asset pipeline validation, an authoritative UDP server scaffold, password/token
primitives, release hash manifests, and platform QA reporting.

## Install and run

Python 3.10+:
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -e ".[render,test]"
pytest
ogce4 create-project --name "My World" --out ./MyWorld
ogce4 editor --project ./MyWorld
ogce4 preview --project ./MyWorld
```
The renderer remains Panda3D-backed. Existing v4.0 controls and project workflows are retained.

## v4.1 module examples
```python
from ogce4.v41.materials import PBRMaterial
from ogce4.v41.terrain import generate_heightfield
from ogce4.v41.profiler import FrameProfiler
from ogce4.v41.editor_history import CommandHistory, SetProperty

mat = PBRMaterial(name="Bronze", metallic=0.85, roughness=0.28)
terrain = generate_heightfield(128, 128, seed=42)
profile = FrameProfiler()
profile.record(1 / 60)
print(profile.snapshot())
scene_object = {"position": [0, 0, 0]}
history = CommandHistory()
history.execute(SetProperty(scene_object, "position", [1, 0, 0]))
history.undo()
```

## Engineering truth / release status

The v4.1 modules are working foundations and validated data/workflow components, not claims of
finished AAA technology. The renderer uses Panda3D rather than a proprietary engine backend.
The GI module is a probe interpolation model, not real-time ray tracing. PostFX and lighting are
configuration models until connected to GPU passes. glTF support validates/inspects glTF JSON and
local buffer references; it is not a complete mesh/animation/skin/texture importer. Terrain creates
heightfield data; renderer mesh/LOD/streaming integration remains further work.

The UDP server is a minimal authoritative prototype, not production multiplayer infrastructure:
it lacks encryption, persistent identities, distributed deployment, DDoS protection, rate-limit
policy, matchmaking integration and load/chaos validation. Password hashing and HMAC development
tokens are primitives, not a full identity provider or billing/licensing service. Release manifests
provide integrity hashes, not publisher signatures or an auto-updater. Production signing requires
a protected CI signing key and platform-specific notarization/signing processes.

Windows, Linux and macOS compatibility must be validated on actual machines. GPU/driver coverage,
performance certification, security penetration testing, accessibility, long soak tests, installer
signing, crash recovery and production operations remain release gates. Never treat a successful
unit test as platform or security certification.

## Previous releases

The v4.0 package and supplied v3.1 source archive are retained in the project history/legacy
directory. Earlier v1.x/v2.x source files were not supplied as independently auditable source in
the preceding build, so this release does not falsely claim byte-for-byte integration of them.
