#!/usr/bin/env sh
set -eu
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e '.[render]'
echo 'OGCE Infinity installed. Run: ogce4 create-project --name "My World" --out MyWorld'
