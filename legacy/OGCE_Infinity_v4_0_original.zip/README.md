# OGCE Infinity v4.0
A Python 3.10+ game-engine foundation with a genuine Panda3D real-time renderer and a compact
Tkinter desktop scene editor. Includes project/scene/asset workflows, multiplayer and matchmaking
models, squad coordination, anti-cheat extension hooks, SQLite persistence, reports, plugins,
opt-in local biofeedback, symbolic multidimensional gameplay, and provider-neutral integration APIs.

This is a runnable vertical slice, not a certified AAA engine or a production-proven rival to
Unreal/Unity/Godot/O3DE. The renderer is real Panda3D; it is not yet a custom AAA PBR renderer.
See docs/RELEASE_GATES.md.

Install:
    python -m venv .venv
    # Windows: .venv\Scripts\activate
    # macOS/Linux: source .venv/bin/activate
    python -m pip install -e ".[render]"
    ogce4 create-project --name "My World" --out ./MyWorld
    ogce4 editor --project ./MyWorld
    ogce4 preview --project ./MyWorld

Editor provides scene hierarchy, inspector, transforms, entity creation/deletion, save and preview.
Preview provides 3D model rendering, lighting, camera orbit, WASD movement and zoom.
